﻿using MvvmCross.Forms.Platforms.Android.Core;

namespace ListViewDemo.Droid
{
    public class Setup : MvxFormsAndroidSetup<Core.App, App>
    {
        public Setup()
        {

        }
    }
}