﻿using ListViewDemo.Views;
using Xamarin.Forms;

namespace ListViewDemo
{
    public partial class App
    {
        public App()
        {
            InitializeComponent();
        }

        protected override void OnStart()
        {
        }

        protected override void OnSleep()
        {
        }

        protected override void OnResume()
        {
        }
    }
}
