﻿namespace ListViewDemo.Controls
{
    public partial class PullToRefresh
    {
        public PullToRefresh()
        {
            InitializeComponent();
        }
    }
}