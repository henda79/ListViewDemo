﻿namespace ListViewDemo.Views.Templates
{
    public partial class ItemTemplate 
    {
        public ItemTemplate()
        {
            InitializeComponent();
        }
    }
}