﻿using System;

namespace ListViewDemo.Views.Templates
{
    public partial class SelectedItemTemplate 
    {
        public SelectedItemTemplate()
        {
            InitializeComponent();
        }

        private void SfButton_OnClicked(object sender, EventArgs e)
        {
            //Menu.ShowAtTouchPoint();
        }
    }
}